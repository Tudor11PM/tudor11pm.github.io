#import "CPClockView.h"
#import "CPPrefs.h"

static CGFloat const kCPMinimumTopInset = 44.0;
static CGFloat const kCPSideMargin      = 12.0;

@interface CPClockView ()
@property (nonatomic, strong) UIView *backdropView;
@property (nonatomic, strong) UIVisualEffectView *blurView;
@property (nonatomic, strong) UILabel *greetingLabel;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UILabel *dateLabel;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) NSDateFormatter *timeFormatter;
@property (nonatomic, strong) NSDateFormatter *dateFormatter;
@property (nonatomic, assign) BOOL temporarySeconds;
@property (nonatomic, copy)   NSString *lastTimeString;
@end

@implementation CPClockView

#pragma mark - Lifecycle

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;

    self.userInteractionEnabled = YES;
    self.backgroundColor = UIColor.clearColor;
    self.clipsToBounds = NO;

    _backdropView = [[UIView alloc] initWithFrame:CGRectZero];
    _backdropView.clipsToBounds = YES;
    _backdropView.userInteractionEnabled = NO;
    _backdropView.hidden = YES;
    [self addSubview:_backdropView];

    _greetingLabel = [self makeLabel];
    _timeLabel     = [self makeLabel];
    _dateLabel     = [self makeLabel];
    [self addSubview:_greetingLabel];
    [self addSubview:_timeLabel];
    [self addSubview:_dateLabel];

    _timeFormatter = [NSDateFormatter new];
    _dateFormatter = [NSDateFormatter new];

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                          action:@selector(handleTap:)];
    [self addGestureRecognizer:tap];

    [NSNotificationCenter.defaultCenter addObserver:self
                                           selector:@selector(significantTimeChange)
                                               name:UIApplicationSignificantTimeChangeNotification
                                             object:nil];

    [self applyPreferences];
    return self;
}

- (UILabel *)makeLabel {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.numberOfLines = 1;
    label.backgroundColor = UIColor.clearColor;
    label.clipsToBounds = NO;
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumScaleFactor = 0.45;
    label.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
    return label;
}

- (void)dealloc {
    [NSNotificationCenter.defaultCenter removeObserver:self];
    [_timer invalidate];
}

- (void)significantTimeChange {
    // Midnight, time zone change, DST: rebuild everything.
    self.lastTimeString = nil;
    [self rebuildFormatters:CPPrefs.shared];
    [self refresh];
}

#pragma mark - Preferences

- (UIFont *)fontWithName:(NSString *)name size:(CGFloat)size weight:(CGFloat)weight {
    size = MAX(6.0, size);
    if (name.length > 0) {
        UIFont *custom = [UIFont fontWithName:name size:size];
        if (custom) return custom;
    }
    // Map 0.0 ... 1.0 onto the UIFontWeight scale (-0.8 ... 0.62)
    CGFloat mapped = -0.8 + (MAX(0.0, MIN(1.0, weight)) * 1.42);
    return [UIFont systemFontOfSize:size weight:mapped];
}

- (void)applyPreferences {
    CPPrefs *prefs = CPPrefs.shared;

    // Only force-hide when the tweak itself is off. When it's on, leave the
    // current hidden state alone — that's owned by -setContextVisible: and
    // mirrors whether the stock clock would be showing right now (idle
    // Lock Screen vs. camera / passcode / search).
    if (!prefs.enabled) {
        self.hidden = YES;
        [self stopUpdating];
    }

    self.greetingLabel.hidden = !prefs.showGreeting;
    self.dateLabel.hidden     = !prefs.showDate;
    if (!prefs.showSeconds) self.temporarySeconds = NO;

    NSTextAlignment alignment = NSTextAlignmentCenter;
    if (prefs.alignment == CPAlignmentLeft)  alignment = NSTextAlignmentLeft;
    if (prefs.alignment == CPAlignmentRight) alignment = NSTextAlignmentRight;

    for (UILabel *label in [self allLabels]) label.textAlignment = alignment;

    self.timeLabel.font = [self fontWithName:prefs.clockFontName
                                        size:prefs.clockFontSize
                                      weight:prefs.clockFontWeight];
    self.timeLabel.textColor = prefs.clockColor;

    self.greetingLabel.font = [self fontWithName:prefs.clockFontName
                                            size:prefs.greetingFontSize
                                          weight:prefs.greetingFontWeight];
    self.greetingLabel.textColor = prefs.greetingColor;

    self.dateLabel.font = [self fontWithName:prefs.clockFontName
                                        size:prefs.dateFontSize
                                      weight:prefs.dateFontWeight];
    self.dateLabel.textColor = prefs.dateColor;

    [self applyShadow:prefs];
    [self rebuildBackdrop:prefs];
    [self rebuildFormatters:prefs];

    self.lastTimeString = nil;
    [self refresh];
}

- (NSArray<UILabel *> *)allLabels {
    return @[ self.greetingLabel, self.timeLabel, self.dateLabel ];
}

- (NSArray<UILabel *> *)visibleLabels {
    NSMutableArray<UILabel *> *visible = [NSMutableArray array];
    for (UILabel *label in [self allLabels]) {
        if (label.hidden) continue;
        if (label.text.length == 0 && label.attributedText.length == 0) continue;
        [visible addObject:label];
    }
    return visible;
}

- (void)applyShadow:(CPPrefs *)prefs {
    for (UILabel *label in [self allLabels]) {
        label.layer.shadowColor   = prefs.shadowColor.CGColor;
        label.layer.shadowOpacity = prefs.shadowEnabled ? (float)prefs.shadowOpacity : 0.0f;
        label.layer.shadowRadius  = prefs.shadowRadius;
        label.layer.shadowOffset  = CGSizeZero;
        label.layer.masksToBounds = NO;
    }
}

- (void)rebuildBackdrop:(CPPrefs *)prefs {
    if (prefs.backdropStyle == CPBackdropNone) {
        self.backdropView.hidden = YES;
        [self.blurView removeFromSuperview];
        self.blurView = nil;
        return;
    }

    self.backdropView.hidden = NO;
    self.backdropView.layer.cornerRadius = prefs.backdropCornerRadius;
    if (@available(iOS 13.0, *)) self.backdropView.layer.cornerCurve = kCACornerCurveContinuous;

    if (prefs.backdropStyle == CPBackdropBlur) {
        self.backdropView.backgroundColor = UIColor.clearColor;
        if (!self.blurView) {
            UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialDark];
            self.blurView = [[UIVisualEffectView alloc] initWithEffect:effect];
            self.blurView.userInteractionEnabled = NO;
            [self.backdropView addSubview:self.blurView];
        }
    } else {
        self.backdropView.backgroundColor = prefs.backdropColor;
        [self.blurView removeFromSuperview];
        self.blurView = nil;
    }
    [self setNeedsLayout];
}

- (void)rebuildFormatters:(CPPrefs *)prefs {
    BOOL seconds = prefs.showSeconds || self.temporarySeconds;

    NSMutableString *format = [NSMutableString string];
    if (prefs.use24Hour) {
        // HH is always two digits: 16:49, 01:00, 00:15
        [format appendString:@"HH:mm"];
    } else {
        [format appendString:prefs.padHourWithZero ? @"hh:mm" : @"h:mm"];
    }
    if (seconds) [format appendString:@":ss"];
    if (!prefs.use24Hour && prefs.showAMPM) [format appendString:@" a"];

    // A fixed locale keeps the 24-hour format even if the region would
    // otherwise force a 12-hour clock, and keeps digits latin.
    self.timeFormatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_GB"];
    self.timeFormatter.dateFormat = format;

    self.dateFormatter.locale = NSLocale.autoupdatingCurrentLocale;
    self.dateFormatter.dateFormat = prefs.dateFormat.length ? prefs.dateFormat : @"EEEE, d MMMM";
}

#pragma mark - Content

- (NSString *)greetingForDate:(NSDate *)date prefs:(CPPrefs *)prefs {
    NSCalendar *calendar = NSCalendar.currentCalendar;
    NSInteger hour    = [calendar component:NSCalendarUnitHour fromDate:date];
    NSInteger weekday = [calendar component:NSCalendarUnitWeekday fromDate:date]; // 1 = Sunday

    NSString *timeGreeting;
    if (hour < 5)       timeGreeting = @"Good night";
    else if (hour < 12) timeGreeting = @"Good morning";
    else if (hour < 18) timeGreeting = @"Good afternoon";
    else if (hour < 22) timeGreeting = @"Good evening";
    else                timeGreeting = @"Good night";

    static NSDateFormatter *symbolFormatter = nil;
    static dispatch_once_t symbolToken;
    dispatch_once(&symbolToken, ^{
        symbolFormatter = [NSDateFormatter new];
        symbolFormatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_GB"];
    });

    NSArray<NSString *> *symbols = symbolFormatter.standaloneWeekdaySymbols;
    NSString *weekdayName = ((NSInteger)symbols.count >= weekday) ? symbols[weekday - 1] : @"";
    NSString *weekdayGreeting = weekdayName.length ? [NSString stringWithFormat:@"Happy %@", weekdayName]
                                                   : timeGreeting;

    NSString *greeting = timeGreeting;
    if (prefs.greetingStyle == CPGreetingStyleWeekday) {
        greeting = weekdayGreeting;
    } else if (prefs.greetingStyle == CPGreetingStyleSmart) {
        BOOL isWeekendish = (weekday == 6 || weekday == 7 || weekday == 1); // Fri / Sat / Sun
        greeting = (isWeekendish && hour >= 5 && hour < 22) ? weekdayGreeting : timeGreeting;
    }

    NSString *name = [prefs.userName stringByTrimmingCharactersInSet:
                      NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if (name.length > 0) greeting = [NSString stringWithFormat:@"%@, %@", greeting, name];
    return greeting;
}

- (void)refresh {
    CPPrefs *prefs = CPPrefs.shared;
    if (!prefs.enabled) return;

    NSDate *now = [NSDate date];
    NSString *timeString = [self.timeFormatter stringFromDate:now];
    if (self.lastTimeString && [timeString isEqualToString:self.lastTimeString]) return;
    self.lastTimeString = timeString;

    if (prefs.clockLetterSpacing != 0.0) {
        self.timeLabel.text = nil;
        self.timeLabel.attributedText =
            [[NSAttributedString alloc] initWithString:timeString
                                            attributes:@{ NSKernAttributeName: @(prefs.clockLetterSpacing) }];
    } else {
        self.timeLabel.attributedText = nil;
        self.timeLabel.text = timeString;
    }

    self.dateLabel.text = prefs.showDate
        ? (prefs.dateUppercase ? [self.dateFormatter stringFromDate:now].uppercaseString
                               : [self.dateFormatter stringFromDate:now])
        : nil;

    self.greetingLabel.text = prefs.showGreeting ? [self greetingForDate:now prefs:prefs] : nil;

    if (self.superview) [self positionInParent:self.superview];
    [self setNeedsLayout];
}

#pragma mark - Timer

- (void)startUpdating {
    [self cp_startTimerWithFade:YES];
}

- (void)cp_startTimerWithFade:(BOOL)fade {
    [self stopUpdating];
    CPPrefs *prefs = CPPrefs.shared;
    if (!prefs.enabled) return;

    NSTimeInterval interval = (prefs.showSeconds || self.temporarySeconds) ? 1.0 : 2.0;
    NSTimer *timer = [NSTimer timerWithTimeInterval:interval
                                             target:self
                                           selector:@selector(refresh)
                                           userInfo:nil
                                            repeats:YES];
    timer.tolerance = interval * 0.1;
    [NSRunLoop.mainRunLoop addTimer:timer forMode:NSRunLoopCommonModes];
    self.timer = timer;

    self.lastTimeString = nil;
    [self refresh];

    if (fade && prefs.fadeInAnimation) {
        self.alpha = 0.0;
        [UIView animateWithDuration:0.45
                              delay:0.05
                            options:UIViewAnimationOptionCurveEaseOut
                         animations:^{ self.alpha = 1.0; }
                         completion:nil];
    } else {
        self.alpha = 1.0;
    }
}

- (void)stopUpdating {
    [self.timer invalidate];
    self.timer = nil;
}

#pragma mark - Context visibility

- (void)setContextVisible:(BOOL)visible {
    if (visible) {
        if (self.hidden) {
            // Coming back from camera / passcode / search: show and fade in.
            self.hidden = NO;
            [self cp_startTimerWithFade:YES];
        } else if (!self.timer) {
            // Already visible (e.g. right after a settings change) — just
            // make sure the clock keeps ticking, no need to fade again.
            [self cp_startTimerWithFade:NO];
        }
    } else {
        if (!self.hidden) {
            self.hidden = YES;
            [self stopUpdating];
        }
    }
}

- (void)refreshTickInterval {
    if (self.hidden) return;
    [self cp_startTimerWithFade:NO];
}

#pragma mark - Interaction

- (void)handleTap:(UITapGestureRecognizer *)gesture {
    CPPrefs *prefs = CPPrefs.shared;
    if (!prefs.tapToggleSeconds || prefs.showSeconds) return;

    self.temporarySeconds = !self.temporarySeconds;
    [self rebuildFormatters:prefs];
    [self startUpdating];

    if (@available(iOS 10.0, *)) {
        UIImpactFeedbackGenerator *feedback =
            [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
        [feedback impactOccurred];
    }
}

#pragma mark - Layout

- (CGFloat)currentPadding {
    return (CPPrefs.shared.backdropStyle == CPBackdropNone) ? 0.0 : CPPrefs.shared.backdropPadding;
}

- (CGSize)contentSizeForWidth:(CGFloat)width {
    NSArray<UILabel *> *labels = [self visibleLabels];
    CGFloat spacing = CPPrefs.shared.elementSpacing;
    CGSize total = CGSizeZero;
    for (UILabel *label in labels) {
        CGSize fit = [label sizeThatFits:CGSizeMake(CGFLOAT_MAX, CGFLOAT_MAX)];
        total.width  = MAX(total.width, ceil(fit.width));
        total.height += ceil(fit.height);
    }
    if (labels.count > 1) total.height += spacing * (labels.count - 1);
    total.width = MIN(total.width, width);
    return total;
}

- (CGSize)sizeThatFits:(CGSize)size {
    CGFloat padding = [self currentPadding];
    CGSize content = [self contentSizeForWidth:size.width - padding * 2];
    return CGSizeMake(content.width + padding * 2, content.height + padding * 2);
}

- (void)layoutSubviews {
    [super layoutSubviews];

    self.backdropView.frame = self.bounds;
    self.blurView.frame = self.backdropView.bounds;

    CGFloat padding = [self currentPadding];
    CGRect content = CGRectInset(self.bounds, padding, padding);
    CGFloat spacing = CPPrefs.shared.elementSpacing;
    CPAlignment alignment = CPPrefs.shared.alignment;

    CGFloat y = CGRectGetMinY(content);
    for (UILabel *label in [self visibleLabels]) {
        CGSize fit = [label sizeThatFits:CGSizeMake(CGFLOAT_MAX, CGFLOAT_MAX)];
        CGFloat height = ceil(fit.height);
        CGFloat width  = MIN(ceil(fit.width), CGRectGetWidth(content));

        CGFloat x;
        if (alignment == CPAlignmentLeft) {
            x = CGRectGetMinX(content);
        } else if (alignment == CPAlignmentRight) {
            x = CGRectGetMaxX(content) - width;
        } else {
            x = CGRectGetMinX(content) + (CGRectGetWidth(content) - width) / 2.0;
        }

        label.frame = CGRectMake(round(x), round(y), width, height);
        y += height + spacing;
    }
}

- (void)positionInParent:(UIView *)parent {
    if (!parent) return;
    CPPrefs *prefs = CPPrefs.shared;

    CGFloat maxWidth = MAX(40.0, CGRectGetWidth(parent.bounds) - kCPSideMargin * 2);
    CGSize fit = [self sizeThatFits:CGSizeMake(maxWidth, CGFLOAT_MAX)];
    if (fit.width <= 0 || fit.height <= 0) return;

    CGFloat topInset = kCPMinimumTopInset;
    if (@available(iOS 11.0, *)) topInset = MAX(parent.safeAreaInsets.top, kCPMinimumTopInset);

    CGFloat originX;
    if (prefs.alignment == CPAlignmentLeft) {
        originX = kCPSideMargin;
    } else if (prefs.alignment == CPAlignmentRight) {
        originX = CGRectGetWidth(parent.bounds) - fit.width - kCPSideMargin;
    } else {
        originX = (CGRectGetWidth(parent.bounds) - fit.width) / 2.0;
    }

    CGRect frame = CGRectMake(round(originX + prefs.offsetX),
                              round(topInset + 24.0 + prefs.offsetY),
                              fit.width,
                              fit.height);
    if (!CGRectEqualToRect(frame, self.frame)) {
        self.frame = frame;
        [self setNeedsLayout];
    }
}

@end
