# ClockPlus

Ceas complet personalizabil pentru Lock Screen (iOS 14+), cu panou de setari nativ.
Suporta **rootful**, **rootless** si **roothide**.

## Ce face

- Pozitionare libera pe X si pe Y (slidere), plus aliniere stanga / centru / dreapta
- Culoare separata pentru ceas, data si mesajul de salut (color picker RGBA inclus in bundle)
- Secunde live, cu **toggle** din setari — implicit oprite
- Format 12h / 24h, AM/PM optional
- Salut deasupra ceasului: "Good morning, Tudor" / "Good evening, ..." / "Happy Friday, ..."
  - **Time** — dupa ora din zi
  - **Weekday** — dupa ziua saptamanii
  - **Smart** — ziua saptamanii vineri/sambata/duminica, restul dupa ora
  - Numele se ia din campul "Your Name" din preference bundle
- Data cu format Unicode configurabil (`EEEE, d MMMM`, `dd.MM.yyyy`, etc.) + optiune uppercase
- Font size, font weight si letter spacing separat pe fiecare element, plus font custom
- Umbra / glow cu culoare, intensitate si raza reglabile
- Backdrop optional: blur sau culoare, cu corner radius si padding
- Animatie de fade-in la aprinderea ecranului
- Tap pe ceas afiseaza temporar secundele (cu haptic), daca toggle-ul e pornit
- Buton de respring si buton de reset la valorile implicite
- Timer-ul se opreste cand Lock Screen-ul nu e pe ecran (fara consum inutil de baterie)

## Structura

```
ClockPlus/
├── Makefile              # aggregate: tweak + subproject prefs
├── control
├── ClockPlus.plist       # filter: com.apple.springboard
├── Tweak.x               # hook-uri CSCoverSheetViewController / CSTimeView
├── CPPrefs.h/.m          # citire preferinte + parser de culoare hex
├── CPClockView.h/.m      # view-ul propriu-zis (salut + ceas + data)
└── clockplusprefs/
    ├── Makefile
    ├── entry.plist
    ├── CPRootListController.m
    ├── CPColorPickerController.m
    └── Resources/
        ├── Info.plist
        └── Root.plist
```

## Build

Din radacina proiectului:

```bash
# rootful (unc0ver, checkra1n, palera1n rootful)
make package THEOS_PACKAGE_SCHEME=

# rootless (Dopamine, palera1n rootless, XinaA15)
make package THEOS_PACKAGE_SCHEME=rootless

# roothide (necesita theos-ul roothide: https://github.com/roothide/theos)
make package THEOS_PACKAGE_SCHEME=roothide
```

Instalare directa pe device:

```bash
make do THEOS_DEVICE_IP=192.168.1.x THEOS_PACKAGE_SCHEME=rootless
```

Pachetul rezultat apare in `packages/`. Pentru Sileo e suficient sa pui .deb-ul in repo-ul tau
si sa completezi `Depiction:` din `control` cu link-ul depiction-ului.

## Note

- Numele pachetului e `com.tudor.clockplus`. Daca il schimbi, schimba-l si in `CPPrefs.h`,
  `CPRootListController.m`, `CPColorPickerController.m` si in toate campurile `defaults` /
  `PostNotification` din `Root.plist`.
- Pune un `icon.png` (29x29 si @2x/@3x) in `clockplusprefs/Resources/` ca sa apara iconita in Settings.
- Hook-ul de ascundere a ceasului stock foloseste `CSTimeView`. Pe iOS 16+ layout-ul Lock Screen-ului
  e diferit — daca ceasul stock ramane vizibil, dezactiveaza "Hide Stock Clock" si muta ClockPlus
  mai jos cu Y Offset, sau adauga un hook suplimentar pentru clasa de clock din versiunea ta de iOS.
- Culorile sunt salvate in formatul `#RRGGBB:AA` (compatibil cu libcolorpicker), deci daca vrei
  sa inlocuiesti picker-ul inclus cu libcolorpicker, valorile existente raman valide.

---

## Ce s-a schimbat in 1.0.0 (revizia a treia)

- **Bug real, grav:** clock-ul tau aparea peste tot (Camera, ecranul de parola,
  Search) fiindca era adaugat pe view-ul de baza al Cover Sheet-ului, care
  ramane mereu prezent indiferent de context. Acum ceasul **oglindeste**
  exact semnalele pe care Apple le trimite catre ceasul original cand il
  arata/ascunde (`-setAlpha:` / `-setHidden:` pe `CSTimeView`) — ceea ce
  inseamna ca al tau apare si dispare exact in aceleasi locuri ca ceasul din
  fabrica, fara sa ghicesc eu contextele.
- In timp ce scriam fix-ul de mai sus am gasit si reparat un bug pe care
  l-as fi introdus singur: codul de siguranta care fortza ceasul stock
  invizibil in `layoutSubviews` seta `self.alpha`/`self.hidden`, ceea ce
  re-intra in hook-ul meu propriu si strica semnalul oglindit (ceasul tau ar
  fi ramas ascuns permanent dupa primul layout). Acum foloseste direct
  `self.layer.opacity`/`self.layer.hidden`, care nu trece prin metodele
  interceptate.
- **"Hide Stock Clock" a fost eliminat din setari.** Ceasul original e acum
  ascuns necondiționat — nu mai e un switch, e comportamentul implicit si
  singurul comportament.
- **Respring reparat.** Varianta veche cauta binarul `killall` pe cai fixe
  (`/usr/bin/killall`, `/var/jb/usr/bin/killall`...), care difera intre
  rootful/rootless/roothide si pe roothide nici macar nu exista o cale fixa
  (prefixul e randomizat la fiecare boot). Acum cauta procesul SpringBoard
  direct prin `sysctl` si ii trimite semnalul de kill, fara sa depinda de
  niciun path — merge identic pe toate cele 3 variante.
- **Logo-ul din poza ta e acum in bundle in 2 forme:** iconita din lista
  Settings (patrat simplu, fara transparenta — sistemul aplica singur
  colturile rotunjite, iar o imagine cu alpha putea sa nu se afiseze deloc
  pe unele versiuni de iOS) si banner-ul rotunjit din capul panoului.
- **Footer-ul din Settings** spune acum "ClockPlus 1.0.0 — rootful, rootless
  and roothide. Made by Tudor69."
- Am verificat, de 3 ori, ca fiecare cheie din `Root.plist` (cele 31 de
  setari) exista exact cu acelasi nume in `CPPrefs.m`, ca toate cele 14
  slidere folosesc celula custom cu titlu+valoare, si ca toate fisierele .m
  au acolade/paranteze balansate.

### O mentiune onesta

Nu am un iPhone sau un simulator jailbreak aici ca sa rulez efectiv codul —
tot ce am facut e revizuit static (citit cu atentie, verificat logica,
verificat ca toate cheile se potrivesc). Partea de `CPSliderCell` foloseste
o subclasa a clasei private `PSSliderTableCell` din Preferences.framework
(nu are header public, deci m-am bazat pe conventia folosita si de alte
tweak-uri open-source) — daca dupa build sliderele arata ciudat (fara titlu
sau fara valoare), spune-mi exact cum arata si le ajustez targetat, in loc
sa presupun ca totul e perfect.

## Ce s-a schimbat in 1.0.0 (revizia a doua)

- **Ceasul stock dispare sigur.** Pe langa hook-ul pe `CSTimeView` (inclusiv `setAlpha:`,
  ca sistemul sa nu il readuca), Cover Sheet-ul e parcurs recursiv la fiecare layout si se
  ascunde orice view de tip time/date, indiferent de clasa folosita de versiunea ta de iOS.
- **Ora implicita cu 4 cifre.** `HH:mm` fortat pe locale fix `en_GB`, deci 16:49 si 01:00,
  nu 4:49. Pentru modul 12h exista un comutator separat "Leading Zero".
- **Sliderele au acum nume si valoare.** `PSSliderCell` din iOS nu afiseaza label, deci am
  scris o celula proprie (`CPSliderCell`) cu titlu in stanga, valoarea live in dreapta si
  unitatea (pt) unde are sens.
- **Layout rescris fara UIStackView**, cu frame-uri calculate manual — nu mai depinde de
  `systemLayoutSizeFittingSize` si nu mai sare pozitia cand se schimba fontul.
- **Timer corectat** (nu se mai adauga de doua ori in run loop) si se opreste cand Lock
  Screen-ul nu e pe ecran. Plus `UIApplicationSignificantTimeChangeNotification` pentru
  miezul noptii, schimbare de fus orar si ora de vara.
- **Respring** cauta `killall` in toate caile (rootful si rootless), nu doar `/usr/bin`.
- **Logo** din poza ta in preference bundle: iconita in lista Settings + banner in capul
  panoului.

## Important: unde se compileaza

Eu (Claude) nu pot compila binare arm64 pentru iOS in acest mediu — nu am acces
la retea ca sa descarc Theos/SDK-ul iOS si nici la un compilator clang cu
target iOS. Tot ce am facut e codul sursa, scripturile de build si fisierele
de repo. Compilarea (`build.sh`) trebuie rulata pe **desktopul tau**, pe
macOS sau Linux, cu Theos instalat.

Daca nu ai Theos inca:

```bash
# Linux / macOS
git clone --recursive https://github.com/theos/theos.git ~/theos
export THEOS=~/theos
$THEOS/bin/install-macos-deps.sh     # pe macOS
# sau, pe Linux, urmeaza ghidul oficial pentru linux-toolchain + iOS SDK:
# https://theos.dev/docs/installation-linux
```

Ai nevoie si de un iOS SDK (macOS il ai deja daca ai Xcode; pe Linux se
adauga manual in `$THEOS/sdks`). Pentru roothide iti trebuie *in plus*
fork-ul lor de theos:

```bash
git clone --recursive https://github.com/roothide/theos ~/theos-roothide
```

## Build — 3 pachete separate

`control.in` e sablonul din care `build.sh` genereaza automat cate un
`control` diferit pentru fiecare varianta, ca sa nu se suprascrie intre ele:

| Scheme     | Package ID                        | Architecture     | firmware minim |
|------------|------------------------------------|------------------|-----------------|
| rootful    | `com.tudor.clockplus`              | `iphoneos-arm`   | 14.0            |
| rootless   | `com.tudor.clockplus.rootless`     | `iphoneos-arm64` | 15.0            |
| roothide   | `com.tudor.clockplus.roothide`     | `iphoneos-arm64` | 15.0            |

```bash
cd ClockPlus
chmod +x build.sh update-repo.sh
./build.sh all
```

La final ai in `out/`:

```
ClockPlus-1.0.0-rootful.deb
ClockPlus-1.0.0-rootless.deb
ClockPlus-1.0.0-roothide.deb    # doar daca ai theos-roothide configurat
```

Poti compila si o singura varianta: `./build.sh rootless`.

## Push pe repo (tudor11pm.github.io)

Repo-ul tau are deja `debs/`, `Packages*`, `Release` si `dpkg-scanpackages.pl`.
`update-repo.sh` poate copia direct din `out/` si reindexa intr-un pas:

```bash
cp -r repo-files/depictions /cale/catre/tudor11pm.github.io/
cp -r repo-files/icons      /cale/catre/tudor11pm.github.io/

./update-repo.sh /cale/catre/tudor11pm.github.io ./out

cd /cale/catre/tudor11pm.github.io
git add -A
git commit -m "ClockPlus 1.0.0 (rootful, rootless, roothide)"
git push
```

Dupa push: `https://tudor11pm.github.io` in Sileo iti va arata toate cele 3
pachete — utilizatorul (sau tu) alege pe cel potrivit pentru jailbreak-ul
lui. Depiction-ul e la `https://tudor11pm.github.io/depictions/clockplus.html`
(varianta nativa Sileo la `.../clockplus.json`).

### Daca vrei sa dai upload direct pe site, fara git

Site-ul e servit de GitHub Pages direct din branch-ul `main` al repo-ului,
deci "upload direct pe site" tot inseamna push pe git — nu exista un alt
canal de deploy. Poti insa face totul din interfata web a GitHub-ului, fara
terminal pe partea de repo: dupa ce compilezi local cele 3 `.deb`-uri, intri
pe pagina repo-ului, "Add file → Upload files", tragi cele 3 `.deb`-uri in
`debs/`, apoi mai trebuie sa regenerezi `Packages`/`Packages.gz`/`Packages.bz2`
— pentru asta tot ai nevoie sa rulezi `update-repo.sh` local (sau
`dpkg-scanpackages`) inainte de upload, fiindca GitHub Pages nu ruleaza
scripturi la deploy.
