#!/usr/bin/env bash
# ClockPlus build script — produce up to 3 separate .deb files, one per
# jailbreak type, each with its own Package ID so they can sit side by side
# in the same repo without colliding:
#
#   com.tudor.clockplus            (rootful)
#   com.tudor.clockplus.rootless   (rootless)
#   com.tudor.clockplus.roothide   (roothide)
#
# Usage:
#   ./build.sh                -> rootless only (implicit)
#   ./build.sh rootful
#   ./build.sh rootless
#   ./build.sh roothide        -> needs the roothide theos fork, see ROOTHIDE_THEOS below
#   ./build.sh all             -> all three (roothide skipped automatically if not set up)
#
# Output goes to ./out/ as three clearly named .deb files.
set -euo pipefail

: "${THEOS:=$HOME/theos}"
: "${ROOTHIDE_THEOS:=$HOME/theos-roothide}"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT_DIR="$ROOT_DIR/out"
mkdir -p "$OUT_DIR"

# scheme -> package id / name suffix / arch / min firmware / label
variant_package_id() { case "$1" in rootful) echo "com.tudor.clockplus";; rootless) echo "com.tudor.clockplus.rootless";; roothide) echo "com.tudor.clockplus.roothide";; esac; }
variant_name_suffix() { case "$1" in rootful) echo "";; rootless) echo " (Rootless)";; roothide) echo " (RootHide)";; esac; }
variant_arch()        { case "$1" in rootful) echo "iphoneos-arm";; *) echo "iphoneos-arm64";; esac; }
variant_min_fw()       { case "$1" in rootful) echo "14.0";; *) echo "15.0";; esac; }
variant_min_fw_tag()   { case "$1" in rootful) echo "ios14.0";; *) echo "ios15.0";; esac; }
variant_label()        { case "$1" in rootful) echo "rootful";; rootless) echo "rootless";; roothide) echo "roothide";; esac; }

build() {
  local scheme="$1"
  local theos_dir="$THEOS"

  if [ "$scheme" = "roothide" ]; then
    if [ ! -d "$ROOTHIDE_THEOS" ]; then
      echo ""
      echo "!! $ROOTHIDE_THEOS nu exista - sar peste roothide."
      echo "   git clone --recursive https://github.com/roothide/theos \"$ROOTHIDE_THEOS\""
      return 0
    fi
    theos_dir="$ROOTHIDE_THEOS"
  fi

  echo ""
  echo "==> ClockPlus / $scheme"

  cp control control.orig.bak
  trap 'mv -f control.orig.bak control 2>/dev/null || true' RETURN

  sed \
    -e "s/@PACKAGE_ID@/$(variant_package_id "$scheme")/" \
    -e "s/@NAME_SUFFIX@/$(variant_name_suffix "$scheme")/" \
    -e "s/@ARCH@/$(variant_arch "$scheme")/" \
    -e "s/@MIN_FIRMWARE_TAG@/$(variant_min_fw_tag "$scheme")/" \
    -e "s/@MIN_FIRMWARE@/$(variant_min_fw "$scheme")/" \
    -e "s/@VARIANT_LABEL@/$(variant_label "$scheme")/" \
    control.in > control

  make clean >/dev/null 2>&1 || true

  local pkg_scheme_arg=""
  [ "$scheme" != "rootful" ] && pkg_scheme_arg="$scheme"
  THEOS="$theos_dir" make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME="$pkg_scheme_arg"

  mv -f control.orig.bak control
  trap - RETURN

  local built
  built="$(ls -t packages/*.deb 2>/dev/null | head -n1 || true)"
  if [ -z "$built" ]; then
    echo "!! Nu am gasit niciun .deb in packages/ dupa build-ul $scheme"
    return 1
  fi

  local dest="$OUT_DIR/ClockPlus-1.0.0-${scheme}.deb"
  cp -f "$built" "$dest"
  echo "==> $dest"
}

case "${1:-rootless}" in
  all) build rootful; build rootless; build roothide;;
  rootful|rootless|roothide) build "$1";;
  *) echo "Scheme necunoscut: $1 (foloseste rootful | rootless | roothide | all)"; exit 1;;
esac

echo ""
echo "Gata. Pachetele finale sunt in: $OUT_DIR"
ls -1 "$OUT_DIR" 2>/dev/null || true
