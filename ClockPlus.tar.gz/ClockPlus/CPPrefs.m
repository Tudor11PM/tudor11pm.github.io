#import "CPPrefs.h"

#pragma mark - Helpers

static id CPRawValue(NSString *key) {
    CFPreferencesAppSynchronize((__bridge CFStringRef)kCPIdentifier);
    return (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)key,
                                                           (__bridge CFStringRef)kCPIdentifier);
}

static BOOL CPBoolValue(NSString *key, BOOL fallback) {
    id value = CPRawValue(key);
    return [value isKindOfClass:NSNumber.class] ? [value boolValue] : fallback;
}

static CGFloat CPFloatValue(NSString *key, CGFloat fallback) {
    id value = CPRawValue(key);
    return [value isKindOfClass:NSNumber.class] ? (CGFloat)[value doubleValue] : fallback;
}

static NSInteger CPIntValue(NSString *key, NSInteger fallback) {
    id value = CPRawValue(key);
    return [value isKindOfClass:NSNumber.class] ? [value integerValue] : fallback;
}

static NSString *CPStringValue(NSString *key, NSString *fallback) {
    id value = CPRawValue(key);
    if ([value isKindOfClass:NSString.class] && [(NSString *)value length] > 0) return value;
    return fallback;
}

// Accepts "#RRGGBB", "RRGGBB", "#RRGGBBAA" and the libcolorpicker
// format "#RRGGBB:0.85" so the tweak stays compatible with either picker.
UIColor *CPColorFromHexString(NSString *string, UIColor *fallback) {
    if (![string isKindOfClass:NSString.class] || string.length == 0) return fallback;

    CGFloat alpha = 1.0;
    NSArray<NSString *> *parts = [string componentsSeparatedByString:@":"];
    NSString *hex = parts.firstObject;
    if (parts.count > 1) alpha = (CGFloat)[parts[1] doubleValue];

    hex = [[hex stringByReplacingOccurrencesOfString:@"#" withString:@""]
           stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];

    if (hex.length == 3) { // #RGB shorthand
        NSMutableString *expanded = [NSMutableString string];
        for (NSUInteger i = 0; i < 3; i++) {
            NSString *c = [hex substringWithRange:NSMakeRange(i, 1)];
            [expanded appendFormat:@"%@%@", c, c];
        }
        hex = expanded;
    }
    if (hex.length != 6 && hex.length != 8) return fallback;

    unsigned int raw = 0;
    if (![[NSScanner scannerWithString:hex] scanHexInt:&raw]) return fallback;

    CGFloat r, g, b;
    if (hex.length == 8) {
        r = ((raw >> 24) & 0xFF) / 255.0;
        g = ((raw >> 16) & 0xFF) / 255.0;
        b = ((raw >> 8) & 0xFF) / 255.0;
        alpha = (raw & 0xFF) / 255.0;
    } else {
        r = ((raw >> 16) & 0xFF) / 255.0;
        g = ((raw >> 8) & 0xFF) / 255.0;
        b = (raw & 0xFF) / 255.0;
    }
    return [UIColor colorWithRed:r green:g blue:b alpha:MAX(0.0, MIN(1.0, alpha))];
}

#pragma mark - CPPrefs

@implementation CPPrefs

+ (instancetype)shared {
    static CPPrefs *shared = nil;
    static dispatch_once_t token;
    dispatch_once(&token, ^{
        shared = [CPPrefs new];
        [shared reload];
    });
    return shared;
}

- (void)reload {
    // General
    _enabled          = CPBoolValue(@"enabled", YES);
    _fadeInAnimation  = CPBoolValue(@"fadeInAnimation", YES);
    _tapToggleSeconds = CPBoolValue(@"tapToggleSeconds", YES);

    // Layout
    _offsetX          = CPFloatValue(@"offsetX", 0.0);
    _offsetY          = CPFloatValue(@"offsetY", 0.0);
    _elementSpacing   = CPFloatValue(@"elementSpacing", 2.0);
    _alignment        = (CPAlignment)CPIntValue(@"alignment", CPAlignmentCenter);

    // Clock
    _showSeconds        = CPBoolValue(@"showSeconds", NO);
    _use24Hour          = CPBoolValue(@"use24Hour", YES);
    _showAMPM           = CPBoolValue(@"showAMPM", YES);
    _padHourWithZero    = CPBoolValue(@"padHourWithZero", YES);
    _clockFontSize      = CPFloatValue(@"clockFontSize", 76.0);
    _clockFontWeight    = CPFloatValue(@"clockFontWeight", 0.35);
    _clockLetterSpacing = CPFloatValue(@"clockLetterSpacing", 0.0);
    _clockFontName      = CPStringValue(@"clockFontName", @"");
    _clockColor         = CPColorFromHexString(CPStringValue(@"clockColor", nil), UIColor.whiteColor);

    // Date
    _showDate       = CPBoolValue(@"showDate", YES);
    _dateFontSize   = CPFloatValue(@"dateFontSize", 18.0);
    _dateFontWeight = CPFloatValue(@"dateFontWeight", 0.4);
    _dateUppercase  = CPBoolValue(@"dateUppercase", NO);
    _dateFormat     = CPStringValue(@"dateFormat", @"EEEE, d MMMM");
    _dateColor      = CPColorFromHexString(CPStringValue(@"dateColor", nil),
                                           [UIColor colorWithWhite:1.0 alpha:0.75]);

    // Greeting
    _showGreeting       = CPBoolValue(@"showGreeting", YES);
    _greetingStyle      = (CPGreetingStyle)CPIntValue(@"greetingStyle", CPGreetingStyleSmart);
    _userName           = CPStringValue(@"userName", @"");
    _greetingFontSize   = CPFloatValue(@"greetingFontSize", 20.0);
    _greetingFontWeight = CPFloatValue(@"greetingFontWeight", 0.55);
    _greetingColor      = CPColorFromHexString(CPStringValue(@"greetingColor", nil),
                                               [UIColor colorWithWhite:1.0 alpha:0.9]);

    // Effects
    _shadowEnabled        = CPBoolValue(@"shadowEnabled", YES);
    _shadowOpacity        = CPFloatValue(@"shadowOpacity", 0.35);
    _shadowRadius         = CPFloatValue(@"shadowRadius", 6.0);
    _shadowColor          = CPColorFromHexString(CPStringValue(@"shadowColor", nil), UIColor.blackColor);
    _backdropStyle        = (CPBackdropStyle)CPIntValue(@"backdropStyle", CPBackdropNone);
    _backdropColor        = CPColorFromHexString(CPStringValue(@"backdropColor", nil),
                                                 [UIColor colorWithWhite:0.0 alpha:0.25]);
    _backdropCornerRadius = CPFloatValue(@"backdropCornerRadius", 22.0);
    _backdropPadding      = CPFloatValue(@"backdropPadding", 16.0);
}

@end
