#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "CPPrefs.h"
#import "CPClockView.h"

#if __has_include(<roothide.h>)
#import <roothide.h>
#endif

@interface CSCoverSheetViewController : UIViewController
@end

@interface CSTimeView : UIView
@end

static __weak CPClockView *gClockView = nil;

static void *kCPLastAlphaKey  = &kCPLastAlphaKey;
static void *kCPLastHiddenKey = &kCPLastHiddenKey;

#pragma mark - Stock date sweep

// The clock's minutes/hours live in CSTimeView (handled precisely below by
// mirroring its own alpha/hidden calls), but the small date line above/below
// it is a different, undocumented class that varies across iOS versions. We
// sweep for it defensively on every Cover Sheet layout pass and fade out
// anything that looks like a stock date view, so it never doubles up with
// our own date label. This never touches CSTimeView itself.
static BOOL CPIsStockDateView(UIView *view) {
    if ([view isKindOfClass:CPClockView.class]) return NO;
    NSString *name = NSStringFromClass(view.class);
    return [name containsString:@"DateView"] || [name containsString:@"DateLabel"];
}

static void CPHideStockDateViews(UIView *view, NSInteger depth) {
    if (!view || depth > 7) return;
    for (UIView *subview in view.subviews) {
        if (CPIsStockDateView(subview)) {
            if (subview.alpha != 0.0) subview.alpha = 0.0;
            continue;
        }
        CPHideStockDateViews(subview, depth + 1);
    }
}

#pragma mark - Lock Screen container

%group GroupCoverSheet

%hook CSCoverSheetViewController

- (void)viewDidLoad {
    %orig;
    if (!CPPrefs.shared.enabled) return;

    CPClockView *clock = [[CPClockView alloc] initWithFrame:CGRectZero];
    objc_setAssociatedObject(self, @selector(cp_clockView), clock, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    gClockView = clock;
    [self.view addSubview:clock];
}

- (void)viewDidLayoutSubviews {
    %orig;

    CPPrefs *prefs = CPPrefs.shared;
    if (!prefs.enabled) return;

    CPHideStockDateViews(self.view, 0);

    CPClockView *clock = objc_getAssociatedObject(self, @selector(cp_clockView));
    if (!clock) return;
    if (clock.superview != self.view) [self.view addSubview:clock];
    [self.view bringSubviewToFront:clock];
    [clock positionInParent:self.view];
}

%new
- (CPClockView *)cp_clockView {
    return objc_getAssociatedObject(self, @selector(cp_clockView));
}

%end

%end // GroupCoverSheet

#pragma mark - Stock clock: hide it, mirror its visibility onto ours

// CSTimeView is what actually shows/hides the stock time as the Lock Screen
// moves between idle, camera, passcode entry and search. Apple already
// calls -setAlpha: / -setHidden: on it for exactly those transitions — that
// is why the stock clock correctly disappears in those places. Rather than
// re-guessing those transitions ourselves, we capture whatever value Apple
// is about to apply, apply the SAME visibility to our own clock, and then
// force the stock view itself to stay invisible always. This makes our
// clock appear and disappear in exactly the same places the original did.

static void CPMirrorVisibility(CSTimeView *stock) {
    CPClockView *clock = gClockView;
    if (!clock || !CPPrefs.shared.enabled) return;

    NSNumber *lastAlpha  = objc_getAssociatedObject(stock, kCPLastAlphaKey);
    NSNumber *lastHidden = objc_getAssociatedObject(stock, kCPLastHiddenKey);
    CGFloat alpha = lastAlpha ? lastAlpha.doubleValue : 1.0;
    BOOL hidden   = lastHidden ? lastHidden.boolValue : NO;

    [clock setContextVisible:(!hidden && alpha > 0.01)];
}

%group GroupStockClock

%hook CSTimeView

- (void)setAlpha:(CGFloat)alpha {
    objc_setAssociatedObject(self, kCPLastAlphaKey, @(alpha), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    CPMirrorVisibility(self);
    %orig(0.0); // the stock clock itself is always invisible
}

- (void)setHidden:(BOOL)hidden {
    objc_setAssociatedObject(self, kCPLastHiddenKey, @(hidden), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    CPMirrorVisibility(self);
    %orig(YES);
}

- (void)layoutSubviews {
    %orig;
    // Belt and suspenders: force invisible at the CALayer level, not via
    // self.alpha/self.hidden — going through those properties would
    // re-enter our own -setAlpha:/-setHidden: hooks above and corrupt the
    // mirrored signal (it would look like the stock clock just told us to
    // hide, permanently latching our clock hidden after the first layout).
    self.layer.opacity = 0.0f;
    self.layer.hidden  = YES;
}

%end

%end // GroupStockClock

#pragma mark - Preference reloading

static void CPPreferencesChanged(CFNotificationCenterRef center, void *observer,
                                 CFStringRef name, const void *object,
                                 CFDictionaryRef userInfo) {
    [CPPrefs.shared reload];
    dispatch_async(dispatch_get_main_queue(), ^{
        CPClockView *clock = gClockView;
        if (!clock) return;
        [clock applyPreferences];
        [clock refreshTickInterval];
        UIView *parent = clock.superview;
        if (parent) {
            [clock positionInParent:parent];
            [parent setNeedsLayout];
        }
    });
}

%ctor {
    @autoreleasepool {
        [CPPrefs.shared reload];

        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                        NULL,
                                        CPPreferencesChanged,
                                        CFSTR(kCPNotificationName),
                                        NULL,
                                        CFNotificationSuspensionBehaviorDeliverImmediately);

        if (objc_getClass("CSCoverSheetViewController")) %init(GroupCoverSheet);
        if (objc_getClass("CSTimeView")) %init(GroupStockClock);
    }
}
