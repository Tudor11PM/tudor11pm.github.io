#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define kCPIdentifier       @"com.tudor.clockplus"
#define kCPNotificationName  "com.tudor.clockplus/prefschanged"

typedef NS_ENUM(NSInteger, CPAlignment) {
    CPAlignmentLeft   = 0,
    CPAlignmentCenter = 1,
    CPAlignmentRight  = 2
};

typedef NS_ENUM(NSInteger, CPGreetingStyle) {
    CPGreetingStyleTimeOfDay = 0,   // Good morning / afternoon / evening / night
    CPGreetingStyleWeekday   = 1,   // Happy Friday
    CPGreetingStyleSmart     = 2    // weekday on Fri/Sat/Sun, time of day otherwise
};

typedef NS_ENUM(NSInteger, CPBackdropStyle) {
    CPBackdropNone  = 0,
    CPBackdropBlur  = 1,
    CPBackdropSolid = 2
};

UIColor *CPColorFromHexString(NSString *string, UIColor *fallback);

@interface CPPrefs : NSObject

+ (instancetype)shared;
- (void)reload;

// General
@property (nonatomic, assign) BOOL enabled;
@property (nonatomic, assign) BOOL fadeInAnimation;
@property (nonatomic, assign) BOOL tapToggleSeconds;

// Layout
@property (nonatomic, assign) CGFloat offsetX;
@property (nonatomic, assign) CGFloat offsetY;
@property (nonatomic, assign) CGFloat elementSpacing;
@property (nonatomic, assign) CPAlignment alignment;

// Clock
@property (nonatomic, assign) BOOL showSeconds;
@property (nonatomic, assign) BOOL use24Hour;
@property (nonatomic, assign) BOOL showAMPM;
@property (nonatomic, assign) BOOL padHourWithZero;
@property (nonatomic, assign) CGFloat clockFontSize;
@property (nonatomic, assign) CGFloat clockFontWeight;   // 0.0 ultralight ... 1.0 black
@property (nonatomic, assign) CGFloat clockLetterSpacing;
@property (nonatomic, strong) NSString *clockFontName;   // empty = system font
@property (nonatomic, strong) UIColor *clockColor;

// Date
@property (nonatomic, assign) BOOL showDate;
@property (nonatomic, assign) CGFloat dateFontSize;
@property (nonatomic, assign) CGFloat dateFontWeight;
@property (nonatomic, assign) BOOL dateUppercase;
@property (nonatomic, strong) NSString *dateFormat;
@property (nonatomic, strong) UIColor *dateColor;

// Greeting
@property (nonatomic, assign) BOOL showGreeting;
@property (nonatomic, assign) CPGreetingStyle greetingStyle;
@property (nonatomic, strong) NSString *userName;
@property (nonatomic, assign) CGFloat greetingFontSize;
@property (nonatomic, assign) CGFloat greetingFontWeight;
@property (nonatomic, strong) UIColor *greetingColor;

// Effects
@property (nonatomic, assign) BOOL shadowEnabled;
@property (nonatomic, assign) CGFloat shadowOpacity;
@property (nonatomic, assign) CGFloat shadowRadius;
@property (nonatomic, strong) UIColor *shadowColor;
@property (nonatomic, assign) CPBackdropStyle backdropStyle;
@property (nonatomic, strong) UIColor *backdropColor;
@property (nonatomic, assign) CGFloat backdropCornerRadius;
@property (nonatomic, assign) CGFloat backdropPadding;

@end
