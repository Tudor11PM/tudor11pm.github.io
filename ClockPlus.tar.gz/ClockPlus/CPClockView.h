#import <UIKit/UIKit.h>

@interface CPClockView : UIView

/// Re-reads CPPrefs and rebuilds fonts, colours, effects and layout.
- (void)applyPreferences;

/// Starts / stops the ticking timer. Called from the Lock Screen lifecycle
/// so nothing runs while the Lock Screen is not on screen.
- (void)startUpdating;
- (void)stopUpdating;

/// Mirrors the stock clock's own show/hide state (idle Lock Screen vs.
/// camera, passcode entry, search, etc). Fades in when becoming visible if
/// "Fade In" is on, and stops the timer while hidden to save battery.
- (void)setContextVisible:(BOOL)visible;

/// Restarts the tick interval (e.g. after "Show Seconds" changes) without
/// re-triggering the fade-in animation. No-op while hidden.
- (void)refreshTickInterval;

/// Sizes and positions the view inside its parent using the X/Y offsets.
- (void)positionInParent:(UIView *)parent;

@end
