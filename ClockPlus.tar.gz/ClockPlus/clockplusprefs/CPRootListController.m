#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#include <sys/sysctl.h>
#include <signal.h>

static NSString * const kCPIdentifier = @"com.tudor.clockplus";
static NSString * const kCPNotification = @"com.tudor.clockplus/prefschanged";

@interface CPRootListController : PSListController
@end

@implementation CPRootListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"ClockPlus";
    [self buildHeader];
}

#pragma mark - Header

- (void)buildHeader {
    NSBundle *bundle = [NSBundle bundleForClass:self.class];
    UIImage *logo = [UIImage imageNamed:@"Banner" inBundle:bundle compatibleWithTraitCollection:nil];

    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), 170.0)];

    UIImageView *imageView = [[UIImageView alloc] initWithImage:logo];
    imageView.contentMode = UIViewContentModeScaleAspectFill;
    imageView.clipsToBounds = YES;
    imageView.layer.cornerRadius = 20.0;
    if (@available(iOS 13.0, *)) imageView.layer.cornerCurve = kCACornerCurveContinuous;
    imageView.translatesAutoresizingMaskIntoConstraints = NO;
    [header addSubview:imageView];

    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.text = @"ClockPlus";
    titleLabel.font = [UIFont systemFontOfSize:24.0 weight:UIFontWeightBold];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [header addSubview:titleLabel];

    UILabel *subtitleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    subtitleLabel.text = @"A Lock Screen clock, exactly where you want it.";
    subtitleLabel.font = [UIFont systemFontOfSize:13.0];
    subtitleLabel.textAlignment = NSTextAlignmentCenter;
    subtitleLabel.numberOfLines = 2;
    subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    if (@available(iOS 13.0, *)) subtitleLabel.textColor = UIColor.secondaryLabelColor;
    else subtitleLabel.textColor = UIColor.grayColor;
    [header addSubview:subtitleLabel];

    [NSLayoutConstraint activateConstraints:@[
        [imageView.topAnchor constraintEqualToAnchor:header.topAnchor constant:16.0],
        [imageView.centerXAnchor constraintEqualToAnchor:header.centerXAnchor],
        [imageView.widthAnchor constraintEqualToConstant:84.0],
        [imageView.heightAnchor constraintEqualToConstant:84.0],

        [titleLabel.topAnchor constraintEqualToAnchor:imageView.bottomAnchor constant:10.0],
        [titleLabel.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:16.0],
        [titleLabel.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-16.0],

        [subtitleLabel.topAnchor constraintEqualToAnchor:titleLabel.bottomAnchor constant:4.0],
        [subtitleLabel.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:24.0],
        [subtitleLabel.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-24.0]
    ]];

    UITableView *table = (UITableView *)[self table];
    table.tableHeaderView = header;
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    UITableView *table = (UITableView *)[self table];
    UIView *header = table.tableHeaderView;
    if (header && CGRectGetWidth(header.frame) != CGRectGetWidth(table.bounds)) {
        header.frame = CGRectMake(0, 0, CGRectGetWidth(table.bounds), 170.0);
        table.tableHeaderView = header;
    }
}

#pragma mark - Actions

// Looks up a running process by name via sysctl (KERN_PROC_ALL) rather than
// shelling out to `killall`. This avoids relying on any filesystem path —
// killall lives in different places (or may be missing entirely) across
// rootful, rootless and roothide, which is why the old path-guessing
// version of this button could silently do nothing.
static pid_t CPFindProcessID(NSString *processName) {
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0 };
    size_t size = 0;
    if (sysctl(mib, 4, NULL, &size, NULL, 0) != 0 || size == 0) return 0;

    struct kinfo_proc *procs = malloc(size);
    if (!procs) return 0;

    pid_t found = 0;
    if (sysctl(mib, 4, procs, &size, NULL, 0) == 0) {
        NSUInteger count = size / sizeof(struct kinfo_proc);
        for (NSUInteger i = 0; i < count; i++) {
            NSString *name = [NSString stringWithUTF8String:procs[i].kp_proc.p_comm];
            if ([name isEqualToString:processName]) {
                found = procs[i].kp_proc.p_pid;
                break;
            }
        }
    }
    free(procs);
    return found;
}

- (void)respring {
    [self confirmWithTitle:@"Respring"
                   message:@"SpringBoard will restart to apply your changes."
               buttonTitle:@"Respring"
                   handler:^{
        [self postChangeNotification];

        pid_t pid = CPFindProcessID(@"SpringBoard");
        if (pid > 0) {
            kill(pid, SIGKILL);
        } else {
            UIAlertController *alert =
                [UIAlertController alertControllerWithTitle:@"Couldn't respring"
                                                     message:@"SpringBoard's process could not be found. Your settings were saved and will apply next time SpringBoard restarts."
                                              preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }];
}

- (void)resetPreferences {
    [self confirmWithTitle:@"Reset ClockPlus"
                   message:@"Every option goes back to its default value. This cannot be undone."
               buttonTitle:@"Reset"
                   handler:^{
        CFArrayRef keys = CFPreferencesCopyKeyList((__bridge CFStringRef)kCPIdentifier,
                                                   kCFPreferencesCurrentUser,
                                                   kCFPreferencesAnyHost);
        if (keys) {
            for (NSString *key in (__bridge NSArray *)keys) {
                CFPreferencesSetValue((__bridge CFStringRef)key, NULL,
                                      (__bridge CFStringRef)kCPIdentifier,
                                      kCFPreferencesCurrentUser, kCFPreferencesAnyHost);
            }
            CFRelease(keys);
        }
        CFPreferencesSynchronize((__bridge CFStringRef)kCPIdentifier,
                                 kCFPreferencesCurrentUser, kCFPreferencesAnyHost);
        [self postChangeNotification];
        [self reloadSpecifiers];
    }];
}

- (void)confirmWithTitle:(NSString *)title
                 message:(NSString *)message
             buttonTitle:(NSString *)buttonTitle
                 handler:(void (^)(void))handler {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title
                                                                  message:message
                                                           preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:buttonTitle
                                              style:UIAlertActionStyleDestructive
                                            handler:^(UIAlertAction *action) { handler(); }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)postChangeNotification {
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                         (__bridge CFStringRef)kCPNotification,
                                         NULL, NULL, YES);
}

@end
