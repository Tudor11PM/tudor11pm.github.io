#import <Preferences/PSViewController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>

static NSString * const kCPPickerIdentifier = @"com.tudor.clockplus";
static NSString * const kCPPickerNotification = @"com.tudor.clockplus/prefschanged";

@interface CPColorPickerController : PSViewController
@end

@implementation CPColorPickerController {
    NSString *_key;
    NSString *_defaultValue;
    UIView *_previewView;
    UILabel *_hexLabel;
    UISlider *_redSlider;
    UISlider *_greenSlider;
    UISlider *_blueSlider;
    UISlider *_alphaSlider;
}

#pragma mark - Setup

- (void)setSpecifier:(PSSpecifier *)specifier {
    [super setSpecifier:specifier];
    _key = [specifier propertyForKey:@"prefsKey"] ?: @"";
    _defaultValue = [specifier propertyForKey:@"fallback"] ?: @"#FFFFFF:1.00";
    self.title = specifier.name ?: @"Colour";
}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (@available(iOS 13.0, *)) {
        self.view.backgroundColor = UIColor.systemGroupedBackgroundColor;
    } else {
        self.view.backgroundColor = UIColor.groupTableViewBackgroundColor;
    }

    _previewView = [[UIView alloc] initWithFrame:CGRectZero];
    _previewView.layer.cornerRadius = 16.0;
    _previewView.layer.borderWidth = 1.0 / UIScreen.mainScreen.scale;
    _previewView.layer.borderColor = [UIColor colorWithWhite:0.5 alpha:0.4].CGColor;
    _previewView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:_previewView];

    _hexLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _hexLabel.textAlignment = NSTextAlignmentCenter;
    _hexLabel.font = [UIFont monospacedDigitSystemFontOfSize:17.0 weight:UIFontWeightMedium];
    _hexLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:_hexLabel];

    _redSlider   = [self sliderWithTint:UIColor.redColor];
    _greenSlider = [self sliderWithTint:UIColor.greenColor];
    _blueSlider  = [self sliderWithTint:UIColor.blueColor];
    _alphaSlider = [self sliderWithTint:UIColor.grayColor];

    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[
        [self rowWithTitle:@"Red" slider:_redSlider],
        [self rowWithTitle:@"Green" slider:_greenSlider],
        [self rowWithTitle:@"Blue" slider:_blueSlider],
        [self rowWithTitle:@"Opacity" slider:_alphaSlider]
    ]];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 14.0;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:stack];

    UILayoutGuide *guide = self.view.safeAreaLayoutGuide;
    [NSLayoutConstraint activateConstraints:@[
        [_previewView.topAnchor constraintEqualToAnchor:guide.topAnchor constant:24.0],
        [_previewView.centerXAnchor constraintEqualToAnchor:guide.centerXAnchor],
        [_previewView.widthAnchor constraintEqualToConstant:120.0],
        [_previewView.heightAnchor constraintEqualToConstant:80.0],

        [_hexLabel.topAnchor constraintEqualToAnchor:_previewView.bottomAnchor constant:12.0],
        [_hexLabel.centerXAnchor constraintEqualToAnchor:guide.centerXAnchor],

        [stack.topAnchor constraintEqualToAnchor:_hexLabel.bottomAnchor constant:28.0],
        [stack.leadingAnchor constraintEqualToAnchor:guide.leadingAnchor constant:20.0],
        [stack.trailingAnchor constraintEqualToAnchor:guide.trailingAnchor constant:-20.0]
    ]];

    [self loadCurrentColor];
    [self updatePreview];
}

- (UISlider *)sliderWithTint:(UIColor *)tint {
    UISlider *slider = [[UISlider alloc] initWithFrame:CGRectZero];
    slider.minimumValue = 0.0;
    slider.maximumValue = 1.0;
    slider.minimumTrackTintColor = tint;
    [slider addTarget:self action:@selector(sliderChanged) forControlEvents:UIControlEventValueChanged];
    return slider;
}

- (UIView *)rowWithTitle:(NSString *)title slider:(UISlider *)slider {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.text = title;
    label.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightMedium];
    [label setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [label.widthAnchor constraintEqualToConstant:72.0].active = YES;

    UIStackView *row = [[UIStackView alloc] initWithArrangedSubviews:@[ label, slider ]];
    row.axis = UILayoutConstraintAxisHorizontal;
    row.spacing = 10.0;
    row.alignment = UIStackViewAlignmentCenter;
    return row;
}

#pragma mark - Value handling

- (void)loadCurrentColor {
    CFPreferencesAppSynchronize((__bridge CFStringRef)kCPPickerIdentifier);
    NSString *stored = (__bridge_transfer NSString *)
        CFPreferencesCopyAppValue((__bridge CFStringRef)_key,
                                  (__bridge CFStringRef)kCPPickerIdentifier);
    NSString *value = stored.length ? stored : _defaultValue;

    CGFloat alpha = 1.0;
    NSArray<NSString *> *parts = [value componentsSeparatedByString:@":"];
    if (parts.count > 1) alpha = (CGFloat)[parts[1] doubleValue];
    NSString *hex = [parts.firstObject stringByReplacingOccurrencesOfString:@"#" withString:@""];
    if (hex.length != 6) hex = @"FFFFFF";

    unsigned int raw = 0;
    [[NSScanner scannerWithString:hex] scanHexInt:&raw];

    _redSlider.value   = ((raw >> 16) & 0xFF) / 255.0;
    _greenSlider.value = ((raw >> 8) & 0xFF) / 255.0;
    _blueSlider.value  = (raw & 0xFF) / 255.0;
    _alphaSlider.value = MAX(0.0, MIN(1.0, alpha));
}

- (NSString *)currentHexString {
    return [NSString stringWithFormat:@"#%02X%02X%02X:%.2f",
            (unsigned)roundf(_redSlider.value * 255.0),
            (unsigned)roundf(_greenSlider.value * 255.0),
            (unsigned)roundf(_blueSlider.value * 255.0),
            _alphaSlider.value];
}

- (void)updatePreview {
    _previewView.backgroundColor = [UIColor colorWithRed:_redSlider.value
                                                   green:_greenSlider.value
                                                    blue:_blueSlider.value
                                                   alpha:_alphaSlider.value];
    _hexLabel.text = [self currentHexString];
}

- (void)sliderChanged {
    [self updatePreview];
    [self save];
}

- (void)save {
    if (!_key.length) return;
    CFPreferencesSetValue((__bridge CFStringRef)_key,
                          (__bridge CFStringRef)[self currentHexString],
                          (__bridge CFStringRef)kCPPickerIdentifier,
                          kCFPreferencesCurrentUser, kCFPreferencesAnyHost);
    CFPreferencesSynchronize((__bridge CFStringRef)kCPPickerIdentifier,
                             kCFPreferencesCurrentUser, kCFPreferencesAnyHost);
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                         (__bridge CFStringRef)kCPPickerNotification,
                                         NULL, NULL, YES);
}

@end
