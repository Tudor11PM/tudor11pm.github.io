#import <Preferences/PSTableCell.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>

#if __has_include(<Preferences/PSControlTableCell.h>)
#import <Preferences/PSControlTableCell.h>
#else
@interface PSControlTableCell : PSTableCell
- (UIControl *)control;
@end
#endif

#if __has_include(<Preferences/PSSliderTableCell.h>)
#import <Preferences/PSSliderTableCell.h>
#else
@interface PSSliderTableCell : PSControlTableCell
@end
#endif

// PSSliderCell on its own renders a bare slider with no title, which makes a
// panel with a dozen sliders unreadable. This cell adds the specifier name on
// the left and a live value on the right, with the slider on its own row.
@interface CPSliderCell : PSSliderTableCell
@end

@implementation CPSliderCell {
    UILabel *_titleLabel;
    UILabel *_valueLabel;
    NSInteger _decimals;
    NSString *_unit;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style
              reuseIdentifier:(NSString *)reuseIdentifier
                    specifier:(PSSpecifier *)specifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier specifier:specifier];
    if (!self) return nil;

    double maxValue = [[specifier propertyForKey:@"max"] doubleValue];
    _decimals = (maxValue <= 1.5) ? 2 : 0;
    _unit = [specifier propertyForKey:@"unit"] ?: @"";

    _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _titleLabel.text = specifier.name ?: @"";
    _titleLabel.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightMedium];
    [self.contentView addSubview:_titleLabel];

    _valueLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _valueLabel.textAlignment = NSTextAlignmentRight;
    _valueLabel.font = [UIFont monospacedDigitSystemFontOfSize:14.0 weight:UIFontWeightRegular];
    if (@available(iOS 13.0, *)) {
        _titleLabel.textColor = UIColor.labelColor;
        _valueLabel.textColor = UIColor.secondaryLabelColor;
    } else {
        _valueLabel.textColor = UIColor.grayColor;
    }
    [self.contentView addSubview:_valueLabel];

    UIControl *control = [self control];
    if ([control isKindOfClass:UISlider.class]) {
        [control addTarget:self
                    action:@selector(cp_valueChanged)
          forControlEvents:UIControlEventValueChanged];
    }
    [self cp_updateValueLabel];
    return self;
}

- (CGFloat)preferredHeightForWidth:(CGFloat)width {
    return 68.0;
}

- (CGFloat)preferredHeightForWidth:(CGFloat)width inTableView:(UITableView *)tableView {
    return 68.0;
}

- (void)cp_valueChanged {
    [self cp_updateValueLabel];
}

- (void)cp_updateValueLabel {
    UIControl *control = [self control];
    if (![control isKindOfClass:UISlider.class]) return;
    double value = ((UISlider *)control).value;
    NSString *format = (_decimals == 2) ? @"%.2f%@" : @"%.0f%@";
    _valueLabel.text = [NSString stringWithFormat:format, value, _unit];
}

- (void)layoutSubviews {
    [super layoutSubviews];

    // The stock cell would otherwise draw the specifier name on top of ours.
    self.textLabel.text = nil;
    self.detailTextLabel.text = nil;

    CGRect bounds = self.contentView.bounds;
    CGFloat inset = 16.0;
    if (@available(iOS 11.0, *)) inset = MAX(inset, self.contentView.safeAreaInsets.left + 16.0);

    CGFloat usableWidth = CGRectGetWidth(bounds) - inset * 2;
    if (usableWidth <= 0) return;

    _titleLabel.frame = CGRectMake(inset, 9.0, usableWidth * 0.6, 20.0);
    _valueLabel.frame = CGRectMake(CGRectGetWidth(bounds) - inset - usableWidth * 0.35,
                                   9.0, usableWidth * 0.35, 20.0);

    UIControl *control = [self control];
    if ([control isKindOfClass:UISlider.class]) {
        control.frame = CGRectMake(inset, 34.0, usableWidth, 26.0);
    }
    [self cp_updateValueLabel];
}

@end
