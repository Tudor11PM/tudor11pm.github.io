#!/usr/bin/env bash
# Regenereaza indexul repo-ului dupa ce ai pus .deb-urile in debs/.
#
#   ./update-repo.sh /cale/catre/tudor11pm.github.io
#   ./update-repo.sh /cale/catre/tudor11pm.github.io /cale/catre/ClockPlus/out
#
# Al doilea argument (optional) e folderul cu cele 3 .deb-uri proaspat
# compilate - daca il dai, sunt copiate automat in debs/ inainte de reindexare.
set -euo pipefail

REPO="${1:-.}"
SRC="${2:-}"
cd "$REPO"

if [ ! -d debs ]; then
  echo "!! Nu gasesc folderul debs/ in $(pwd)"; exit 1
fi

if [ -n "$SRC" ]; then
  if [ ! -d "$SRC" ]; then
    echo "!! Nu gasesc $SRC"; exit 1
  fi
  echo "==> Copiez .deb din $SRC in debs/"
  cp -f "$SRC"/*.deb debs/
fi

echo "==> Generez Packages din debs/"
if [ -f dpkg-scanpackages.pl ]; then
  perl ./dpkg-scanpackages.pl -m ./debs > Packages
elif command -v dpkg-scanpackages >/dev/null 2>&1; then
  dpkg-scanpackages -m ./debs > Packages
else
  echo "!! Nu am nici dpkg-scanpackages.pl, nici dpkg-scanpackages"; exit 1
fi

echo "==> Comprim"
gzip  -9fkc Packages > Packages.gz
bzip2 -9fkc Packages > Packages.bz2

# Actualizez data din Release daca exista campul
if [ -f Release ]; then
  DATE="$(LC_ALL=C date -u '+%a, %d %b %Y %H:%M:%S UTC')"
  if grep -q '^Date:' Release; then
    sed -i.bak "s|^Date:.*|Date: $DATE|" Release && rm -f Release.bak
  else
    printf 'Date: %s\n' "$DATE" >> Release
  fi
fi

echo ""
echo "==> Pachete indexate:"
grep '^Package:' Packages | sed 's/^/   /'
echo ""
echo "Acum: git add -A && git commit -m 'ClockPlus 1.0.0' && git push"
